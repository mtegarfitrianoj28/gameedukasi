using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nilai : MonoBehaviour
{
    // Start is called before the first frame update
    public void Mudah(){
        Application.LoadLevel("Mudah");
    }
    public void Mudah2(){
        Application.LoadLevel("Mudah2");
    }
    public void Mudah3(){
        Application.LoadLevel("Mudah3");
    }
    public void Mudah4(){
        Application.LoadLevel("Mudah4");
    }
    public void Mudah5(){
        Application.LoadLevel("Mudah5");
    }
    public void Mudah6(){
        Application.LoadLevel("Mudah6");
    }
    public void Mudah7(){
        Application.LoadLevel("Mudah7");
    }
    public void Mudah8(){
        Application.LoadLevel("Mudah8");
    }
    public void Mudah9(){
        Application.LoadLevel("Mudah9");
    }
    public void Mudah10(){
        Application.LoadLevel("Mudah10");
    }
    public void Sedang1(){
        Application.LoadLevel("Sedang1");
    }
    public void Sedang2(){
        Application.LoadLevel("Sedang2");
    }
    public void Sedang3(){
        Application.LoadLevel("Sedang3");
    }
    public void Sedang4(){
        Application.LoadLevel("Sedang4");
    }
    public void Sedang5(){
        Application.LoadLevel("Sedang5");
    }
    public void Sedang6(){
        Application.LoadLevel("Sedang6");
    }
    public void Sedang7(){
        Application.LoadLevel("Sedang7");
    }
    public void Sedang8(){
        Application.LoadLevel("Sedang8");
    }
    public void Sedang9(){
        Application.LoadLevel("Sedang9");
    }
    public void Sedang10(){
        Application.LoadLevel("Sedang10");
    }
    public void Sulit1(){
        Application.LoadLevel("Sulit1");
    }
    public void Sulit2(){
        Application.LoadLevel("Sulit2");
    }
    public void Sulit3(){
        Application.LoadLevel("Sulit3");
    }
    public void Sulit4(){
        Application.LoadLevel("Sulit4");
    }
    public void Sulit5(){
        Application.LoadLevel("Sulit5");
    }
    public void Sulit6(){
        Application.LoadLevel("Sulit6");
    }
    public void Sulit7(){
        Application.LoadLevel("Sulit7");
    }
    public void Sulit8(){
        Application.LoadLevel("Sulit8");
    }
    public void Sulit9(){
        Application.LoadLevel("Sulit9");
    }
    public void Sulit10(){
        Application.LoadLevel("Sulit10");
    }
    public void Nilai0(){
        Application.LoadLevel("Nilai0");
    }
    public void Nilai10(){
        Application.LoadLevel("Nilai10");
    }
    public void Nilai20(){
        Application.LoadLevel("Nilai20");
    }
    public void Nilai30(){
        Application.LoadLevel("Nilai30");
    }
    public void Nilai40(){
        Application.LoadLevel("Nilai40");
    }
    public void Nilai50(){
        Application.LoadLevel("Nilai50");
    }
    public void Nilai60(){
        Application.LoadLevel("Nilai60");
    }
    public void Nilai70(){
        Application.LoadLevel("Nilai70");
    }
    public void Nilai80(){
        Application.LoadLevel("Nilai80");
    }
    public void Nilai90(){
        Application.LoadLevel("Nilai90");
    }
    public void Nilai100(){
        Application.LoadLevel("Nilai100");
    }
}
