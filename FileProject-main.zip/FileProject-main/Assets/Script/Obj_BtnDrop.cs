using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Obj_BtnDrop : MonoBehaviour
{
    public BtnDrop Drop;
    public SpriteRenderer Gambar;
    
}
